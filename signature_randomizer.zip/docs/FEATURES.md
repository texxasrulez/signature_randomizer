# Features

- Multiple signature variants per identity
- Weighted randomization + include toggle
- Compose toolbar shuffle
- AJAX save/duplicate/delete/reorder
- Export/Import JSON
- Skins for classic/elastic/larry and custom themes
- Docs and translations scaffold
